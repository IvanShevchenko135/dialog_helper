class SpeechRecognition(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cnn : __torch__.torch.nn.modules.container.Sequential
  dense : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  lstm : __torch__.torch.nn.modules.rnn.LSTM
  layer_norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_7.LayerNorm
  dropout2 : __torch__.torch.nn.modules.dropout.___torch_mangle_8.Dropout
  final_distribution : __torch__.torch.nn.modules.linear.___torch_mangle_9.Linear
  def forward(self: __torch__.model.SpeechRecognition,
    x: Tensor,
    hidden: Tuple[Tensor, Tensor]) -> Tuple[Tensor, Tuple[Tensor, Tensor]]:
    final_distribution = self.final_distribution
    dropout2 = self.dropout2
    layer_norm2 = self.layer_norm2
    lstm = self.lstm
    dense = self.dense
    cnn = self.cnn
    hx, hx0, = hidden
    input = torch.squeeze(x, 1)
    _0 = (dense).forward((cnn).forward(input, ), )
    input0 = torch.transpose(_0, 0, 1)
    _1, _2, _3, = (lstm).forward(input0, hx, hx0, )
    input1 = torch.gelu((layer_norm2).forward(_1, ))
    _4 = (final_distribution).forward((dropout2).forward(input1, ), )
    return (_4, (_2, _3))
class ActDropNormCNN1D(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  norm : __torch__.torch.nn.modules.normalization.LayerNorm
  def forward(self: __torch__.model.ActDropNormCNN1D,
    argument_1: Tensor) -> Tensor:
    dropout = self.dropout
    norm = self.norm
    input = torch.transpose(argument_1, 1, 2)
    input2 = torch.gelu((norm).forward(input, ))
    return (dropout).forward(input2, )
